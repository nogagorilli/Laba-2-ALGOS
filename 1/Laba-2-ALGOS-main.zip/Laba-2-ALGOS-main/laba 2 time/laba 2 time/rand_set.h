#pragma once
char* random_set();